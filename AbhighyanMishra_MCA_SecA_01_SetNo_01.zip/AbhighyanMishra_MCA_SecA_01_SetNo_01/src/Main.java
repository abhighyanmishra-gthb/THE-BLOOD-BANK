import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;
public class Main {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        Connection con = DBConnection.getConnection();
        System.out.println("ABHIGHYAN MISHRA, ROLL:01, MCA:1A");

        while (true) {
            System.out.println();
            System.out.println("1. Register Donor");
            System.out.println("2. Request Blood");
            System.out.println("3. Use Blood Unit");
            System.out.println("4. Stock Summary");
            System.out.println("5. Exit");
            System.out.print("Enter choice:");

            int ch = in.nextInt();

            switch (ch) {
                case 1: {
                    System.out.print("Enter Name: ");
                    in.nextLine();
                    String name = in.nextLine();

                    System.out.print("Enter Age: ");
                    int age = in.nextInt();

                    System.out.print("Enter Blood Group: ");
                    in.nextLine();
                    String bg = in.nextLine();
                    try {
                        PreparedStatement ps = con.prepareStatement(
                                "INSERT INTO donors (name, age, blood_group, status) VALUES (?, ?, ?, 'available')"
                        );
                        ps.setString(1, name);
                        ps.setInt(2, age);
                        ps.setString(3, bg);
                        ps.executeUpdate();
                    } catch (Exception e) {
                        System.out.println("Error: " + e);
                    }
                    break;
                }
                case 2: {
                    System.out.print("Enter blood group:");
                    in.nextLine();
                    String bg = in.nextLine();
                    try {
                        //query to count the number of units available of the given blood group...
                        PreparedStatement ps1 = con.prepareStatement(
                                "SELECT COUNT(*) FROM donors WHERE blood_group=? AND status='available'"
                        );
                        ps1.setString(1, bg);

                        ResultSet rs1 = ps1.executeQuery();

                        if (rs1.next()) {
                            int count = rs1.getInt(1);
                            System.out.println("Total Units Available: " + count);
                        }

                        //query to fetch the donor id's of the given blood group
                        PreparedStatement ps2 = con.prepareStatement(
                                "SELECT donor_id FROM donors WHERE blood_group=? AND status='available'"
                        );
                        ps2.setString(1, bg);

                        ResultSet rs2 = ps2.executeQuery();

                        System.out.println("Available Donor IDs:");

                        while (rs2.next()) {
                            System.out.println(rs2.getInt("donor_id"));
                        }

                    } catch (Exception e) {
                        System.out.println("Error: " + e);
                    }
                    break;
                }
                case 3: {
                    System.out.print("Enter Donor ID to use blood: ");
                    int id = in.nextInt();

                    try {
                        PreparedStatement ps = con.prepareStatement(
                                "UPDATE donors SET status='used' WHERE donor_id=?"
                        );

                        ps.setInt(1, id);

                        int rows = ps.executeUpdate();

                        if (rows > 0) {
                            System.out.println("Blood unit marked as USED ✅");
                        } else {
                            System.out.println("Invalid Donor ID ❌");
                        }

                    } catch (Exception e) {
                        System.out.println("Error: " + e);
                    }
                    break;
                }
                case 4: {
                    try {
                        Statement st = con.createStatement();

                        ResultSet rs = st.executeQuery(
                                "SELECT blood_group, COUNT(*) AS total FROM donors WHERE status='available' GROUP BY blood_group"
                        );

                        System.out.println("Blood Stock Summary:");

                        while (rs.next()) {
                            String bg = rs.getString("blood_group");
                            int count = rs.getInt("total");

                            System.out.println(bg + " : " + count);
                        }

                    } catch (Exception e) {
                        System.out.println("Error: " + e);
                    }
                    break;
                }

                case 5:
                    System.exit(0);
            }
        }
    }


}

