import java.sql.Connection;
import java.sql.DriverManager;

    public class DBConnection {

        public static Connection getConnection() {
            Connection con = null;

            try {
                con = DriverManager.getConnection(
                        "jdbc:mysql://localhost:3306/bloodbank",
                        "root",
                        "Abhigyanlab"
                );
                if (con != null) {
                    System.out.println("Connection Successful With Database...");
                }
            } catch (Exception e) {
                System.out.println("Connection Error: " + e);
            }

            return con;
        }
    }

