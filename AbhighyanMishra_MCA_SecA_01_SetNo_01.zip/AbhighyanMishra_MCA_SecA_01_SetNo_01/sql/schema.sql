CREATE TABLE donors (
                        donor_id     INT PRIMARY KEY AUTO_INCREMENT,
                        name         VARCHAR(100),
                        age          INT,
                        blood_group  VARCHAR(5),
                        donated_on   DATE DEFAULT (CURRENT_DATE),
                        status       ENUM('available','used') DEFAULT 'available'
);
